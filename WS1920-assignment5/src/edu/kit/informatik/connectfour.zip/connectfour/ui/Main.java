package edu.kit.informatik.connectfour.ui;

/*
start torus
select 11
place 1;4
select 7
place 3;0
select 5
place 4;1
select 15
place 2;5

*/

public final class Main {
    public static void main(String[] args) {
        new Runner().run();
    }
}
