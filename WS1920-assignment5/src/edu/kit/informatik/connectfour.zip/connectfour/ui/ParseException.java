package edu.kit.informatik.connectfour.ui;

class ParseException extends Exception {
    ParseException(String message) {
        super(message);
    }
}
