package edu.kit.informatik.connectfour.model;

public class RuleException extends Exception {
    public RuleException(String message) {
        super(message);
    }
}
