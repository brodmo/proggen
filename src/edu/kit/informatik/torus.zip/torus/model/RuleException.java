package edu.kit.informatik.torus.model;

public class RuleException extends Exception {

    public RuleException(String message) {
        super(message);
    }
}
