package edu.kit.informatik.torus.model;

public enum BoardType {
    TORUS, STANDARD;
}